﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Index.aspx.cs" Inherits="Example.Index" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
        </div>
        <asp:Label ID="Label1" runat="server" Text="Please insert your access key : "></asp:Label>
        <asp:TextBox ID="AccessKeyTxt" runat="server"></asp:TextBox>
        <asp:Button ID="Button1" runat="server" OnClick="Button1_Click" style="height: 26px" Text="Authorize" />
        <p>
            <asp:Label ID="authResult" runat="server"></asp:Label>
            <asp:Label ID="token" runat="server"></asp:Label>
        </p>
        <asp:Panel ID="Panel1" runat="server" Height="543px">
            <asp:Label ID="Label2" runat="server" Text="Language : "></asp:Label>
            <asp:DropDownList ID="LangugeDropDown" runat="server">
                <asp:ListItem>EN</asp:ListItem>
                <asp:ListItem>NL</asp:ListItem>
                <asp:ListItem>FR</asp:ListItem>
                <asp:ListItem>DE</asp:ListItem>
                <asp:ListItem>IT</asp:ListItem>
                <asp:ListItem>PL</asp:ListItem>
                <asp:ListItem>PT</asp:ListItem>
                <asp:ListItem>RU</asp:ListItem>
                <asp:ListItem>ES</asp:ListItem>
            </asp:DropDownList>
            <br />
            <br />
            <asp:Button ID="getProductsBtn" runat="server" OnClick="getProductsBtn_Click" Text="Produtcs" />
            <br />
            <asp:TextBox ID="TextBox1" runat="server" Height="317px" TextMode="MultiLine" Width="1139px"></asp:TextBox>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
        </asp:Panel>
        <p>
            &nbsp;</p>
        <p>
            &nbsp;</p>
        <p>
            &nbsp;</p>
    </form>
</body>
</html>
