﻿using Example.StrickerService;
using Newtonsoft.Json;
using System;
using System.ServiceModel;

namespace Example
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Panel1.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var service = new StrickerServiceClient();
            var accessKey = AccessKeyTxt.Text;
            var response = service.AuthenticateClient(accessKey);
            if (response.ErrorCode != null)
            {
                authResult.Text = "Acess dennied - " + response.ErrorMessage;

            }
            else
            {
                token.Text = response.Token;
                authResult.Text = "Acess granted";
                Panel1.Visible = true;
            }
        }

        protected void getProductsBtn_Click(object sender, EventArgs e)
        {
            var service = new StrickerServiceClient();
            ((BasicHttpBinding)service.ChannelFactory.Endpoint.Binding).MaxReceivedMessageSize = 20000000;
            var products = service.Products(token.Text, LangugeDropDown.SelectedValue);
            TextBox1.Text = JsonConvert.SerializeObject(products.Products);
            
            Panel1.Visible = true;
        }
    }
}